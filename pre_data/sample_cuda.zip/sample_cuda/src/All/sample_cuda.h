std::vector<torch::Tensor> sample_forward(torch::Tensor features, torch::Tensor features_loc, torch::Tensor spa_spe);
