import numpy as np
import torch

from torch.autograd import Function
import sys
import  os
import GCN_Sample,GCN_Sample_split

class SampleFunction(Function):

    @staticmethod
    def forward(ctx,features,features_loc,spa_window,spe_threshold,spe_retain):
        features = torch.from_numpy(features).float().cuda()
        features_loc = torch.from_numpy(features_loc).float().cuda()
        spa_spe = torch.Tensor([spa_window,spe_threshold]).float().cuda()

        output = GCN_Sample.forward(features, features_loc,spa_spe)

        adj_sample_spa = output[0]
        adj_sample_spe = output[1]

        b = adj_sample_spe.detach()
        b = torch.sort(b,dim=1).values
        adj_sample_spe = torch.where(adj_sample_spe>b[:,-(spe_retain+1)],adj_sample_spe,torch.zeros_like(adj_sample_spe))
        return adj_sample_spa,adj_sample_spe.t()

class SampleSplitFunction(Function):

    @staticmethod
    def forward(ctx,features,features_loc,spa_window,spe_threshold,spe_retain):

        features = torch.from_numpy(features).float().cuda()
        num_sample = features.size()[0]
        features_loc = torch.from_numpy(features_loc).float().cuda()
        spa_spe = torch.Tensor([spa_window,spe_threshold]).float().cuda()
        index = torch.arange(num_sample,dtype=torch.float32).cuda()
        # output1 = GCN_Sample.forward(features, features_loc,spa_spe)

        split_num = int(np.ceil((num_sample**2)/2e8))
        split_len = (num_sample**2)//split_num
        adj_sample_spa = torch.zeros([num_sample,num_sample]).type_as(features)
        adj_sample_spe = torch.zeros([num_sample,num_sample]).type_as(features)
        for ind in range(split_num):
            if (ind+1)*split_len>num_sample:
                select = index[ind*split_len:]
            else:
                select = index[ind*split_len:(ind+1)*split_len]
            spa,spe = GCN_Sample_split.forward(features, features_loc,spa_spe,select)
            select = select.long()
            adj_sample_spa[select]=spa
            adj_sample_spe[select]=spe
        adj_sample_spa=adj_sample_spa+adj_sample_spa.t()
        adj_sample_spe=adj_sample_spe+adj_sample_spe.t()
        eye = torch.eye(num_sample).bool()
        adj_sample_spa[eye]/=2
        adj_sample_spe[eye]/=2
        # adj_sample_spa = output1[0]
        # adj_sample_spe = output1[1]

        b = adj_sample_spe.detach()
        b = torch.sort(b,dim=1).values
        adj_sample_spe = torch.where(adj_sample_spe>b[:,-(spe_retain+1)],adj_sample_spe,torch.zeros_like(adj_sample_spe))
        return adj_sample_spa,adj_sample_spe.t()

def cuSample(features,features_loc,spa_window,spe_threshold,spe_retain):
    adj_sample_spa,adj_sample_spe=SampleSplitFunction.apply(features,features_loc,spa_window,spe_threshold,spe_retain)
    return adj_sample_spa.cpu().numpy(),adj_sample_spe.cpu().numpy()